// let device = {
//   name: 'iPad', 
//   'storage': '512 GB',
//   color: 'blue', 
//   'price': 599
// }

// console.log(device)
// console.log(device.name)
// console.log(typeof device.name)
// console.log(device.price)
// console.log(typeof device.price)

// for (let prop in device) {
//   console.log(`prop name: ${prop}`)
//   console.log(`prop data type: ${typeof prop}`)
//   console.log(`prop value: ${device[prop]}`)
//   // device['name']
//   // device['storage']
//   // device['color']
//   // device['price']
//   // device.'name' --> this WILL NOT work because the properties are evaluated as strings
//   console.log(`prop value data type: ${typeof device[prop]}`)
// }

// let person = {
//   firstName: 'Brent',
//   lastName: 'Jingle',
//   age: 36
// };

// // console.log(person.firstName)
// // console.log(person['lastName'])

// // for (let prop in person) {
// //   console.log(person[prop])
// // }

// person.pets = [
//   {
//     name: 'Rudolph', 
//     type: 'reindeer', 
//     age: 7
//   },
//   {
//     name: 'Sparky', 
//     type: 'dog', 
//     age: 2
//   }
// ]

// person['sunsFan'] = true

// console.log(person.pets[1].age)

// console.log(person.sunsFan)

// console.log(person)

// class Cat {
//   constructor(name, age, color) {
//     this.name = name
//     this.age = age 
//     this.color = color
//     this.emotions = {
//       happy: false, 
//       sad: false
//     }
//   }

//   meow() {
//     // console.log(`Meow, my name is ${this.name}.`)
//     return `Meow, my name is ${this.name}.`
//   }

//   getMood() {
//     // if (this.emotions.happy)
//     if (this.emotions.happy === true) {
//       console.log('I am one happy cat.')
//     } else {
//       console.log('I hate everyone.')
//       this.emotions.happy = true
//       // this['emotions']['happy'] = true
//     }
//   }
// }

// class Cat {
//   constructor(name, age, color) {
//     this.name = name
//     this.age = age 
//     this.color = color
//     this.emotions = {
//       happy: false, 
//       sad: false
//     }
//   }

//   meow() {
//     console.log(`Meow, my name is ${this.name}.`)
//   }

//   getMood() {
//     if (this.emotions.happy === true) {
//       console.log('I am one happy cat.')
//     } else {
//       console.log('I hate everyone.')
//       this.emotions.happy = true
//     }
//   }
// }

// let frannie = new Cat('Frannie', 9, 'black')
// let thundercat = new Cat('Thunder', 3, 'gray')

// let franniesMeow = frannie.meow()
// let thundersMeow = thundercat.meow()
// frannie['meow']()

// console.log(frannie)

// console.log(1, frannie)
// frannie.getMood()
// console.log(2, frannie)
// frannie.getMood()
// console.log(3, frannie)
// frannie.getMood()
// console.log(4, frannie)


// for (let key in frannie) {
//   if (typeof frannie[key] === 'number') {
//     console.log(`The ${key}'s value is a number`)
//   } else {
//     console.log(`The ${key}'s value is NOT a number`)
//   }
// }



// function multiplyThenAdd(num1, num2) {
//   let result = num1 * num2 
//   result = result + 10
//   return result
// }

// let oneTwo = multiplyThenAdd(1, 2)
// let threeFour = multiplyThenAdd(3, 4)

// console.log(oneTwo)
// console.log(threeFour)

// class Cat {
//   constructor(name, almond, color) {
//     this.name = name
//     this.age = almond 
//     this.pencil = color
//   }
// }

// let obj = {
//   firstValue: true, 
//   secondValue: false
// }

// let obj = {
//   firstValue: true, 
//   secondValue: 'false'
// }

// if (obj.firstValue === true) {
//   console.log('hey there')
// }

// if (obj.secondValue === false) {
//   console.log('twinkle twinkle little star')
// }

class BoardGame {
  constructor(name, rating, numOfPlayers, time) {
    this.name = name
    this.rating = rating
    this.numOfPlayers = numOfPlayers 
    this.timeToPlay = time
  }
}

class Vehicle {
  constructor(type, color, numOfWheels) {
    this.type = type 
    this.color = color
    this.numOfWheels = numOfWheels
  }
}

let splendor = new BoardGame('Splendor', 5, '2-4', '15-30 minutes')
let villagers = new BoardGame('Villagers', 5, '1-5', '30-60 minutes')

let bike = new Vehicle('bicycle', 'yellow', 2)
let boat = new Vehicle('boat', 'sparkly red', 0)

function getObjInfo(obj) {
  let numberOfProps = 0
  let keyNames = []
  let keyValues = []

  for (let key in obj) {
    numberOfProps++

    console.log('key name:', key)
    keyNames.push(key)

    console.log('key value:', obj[key])
    // splendor['rating']
    keyValues.push(obj[key])
  }

  return {
    howManyProps: numberOfProps, 
    whatAreTheirNames: keyNames, 
    whatAreTheirValues: keyValues
  }
}

// console.log(getObjInfo(bike))
getObjInfo(splendor)